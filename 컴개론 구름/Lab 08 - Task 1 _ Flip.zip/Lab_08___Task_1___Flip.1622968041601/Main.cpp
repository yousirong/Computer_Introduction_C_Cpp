#include <iostream>
using namespace std;
int main() {
	unsigned short int input;
	cin >> input;
	cout << ~input << endl; // 0->1, 1->0  using Not(~) operator
	
	return 0;
}