#include <iostream>
using namespace std;

int countTrailingZero(int);

int main() {
	int input;
	cin >> input;
	cout << countTrailingZero(input) << endl;
	
	return 0;
}

int countTrailingZero(int x) {  // '>>' is left shift??
	unsigned int n = x;  // Receives int type and converts to unsigned int type
	int count =0 ;
	while((n & 1) == 0){   // right shift(>>) by while(n&1) == 0
		n = n >> 1;
		count++;
	}
	return count;
}