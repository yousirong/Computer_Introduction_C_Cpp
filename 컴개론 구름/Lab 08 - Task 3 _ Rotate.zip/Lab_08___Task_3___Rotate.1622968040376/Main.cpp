#include <iostream>
using namespace std;

int main() {
	unsigned short int input, lsft, rsft;
	int shift;
	cin >> input >> shift;
	lsft = input << shift;
	rsft = input >> shift;
	cout << lsft << " " << rsft << endl;
	return 0;
}