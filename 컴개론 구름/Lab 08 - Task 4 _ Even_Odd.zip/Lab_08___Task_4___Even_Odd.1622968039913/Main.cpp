#include <iostream>
using namespace std;
int evenOdd (int);   // Function 'evenOdd' declaration

int main() {
	int input;
	cin >> input;
	// Output 'is even' or 'is odd' through a conditional statement
	// in the main statement in the main statement
	if (evenOdd(input) == 1){   
		cout << input << " is odd";
	}else if (evenOdd(input) == 0){
		cout << input << " is even";
	}
	return 0;
}

int evenOdd(int n){    // Function 'evenOdd' content
	unsigned int x = n;  // Convert variable n to unsigned int
	int result;        // result is a variable to return 1 or 0
	if((x & 1) == 1){   // 1 & 1 == 1 (odd)
		result = 1;
		return result;
	}
	else if ((x & 1) == 0){  // 0 & 1 == 0 (even)
		result = 0;
		return result;
	}
}