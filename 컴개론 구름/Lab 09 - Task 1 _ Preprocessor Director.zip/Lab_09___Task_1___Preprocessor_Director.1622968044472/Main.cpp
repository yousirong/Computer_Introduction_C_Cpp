#define grade 1

#ifdef grade 1
	#define cp 3
	#define py 2 
#endif
#ifdef grade 2
	#define db 3
	#define algo 3
	#define web 3
#endif
#ifndef grade
	// Junior and senior use a different program!
	#error Junior and senior use a different program!
#endif
#include <iostream>
using namespace std;

int main() {
	#if grade == 1
		cout << "Total credits are " << cp + py << endl;
	#elif grade == 2
		cout << "Total credits are " << db + algo + web << endl;
	#endif
	return 0;
}