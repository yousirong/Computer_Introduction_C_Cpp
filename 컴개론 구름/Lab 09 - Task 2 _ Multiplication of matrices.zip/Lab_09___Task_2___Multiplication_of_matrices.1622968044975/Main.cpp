#include <iostream>
using namespace std;
int main() {
	int N, M;
	cin >> N >> M;
	if (N != M){
		cout << "It's not a square matrix.";
	}
	else if (N == M){
	int mat[N][M];
	for(int i=0; i<N; i++){
		for(int j=0; j<M; j++){
			cin >> mat[i][j];
		}
	}
	int trace = 0;
	for(int i=0; i<N; ++i){
		trace += mat[i][i];
	}
	cout <<"Trace of the matrix is " << trace << endl;
	}
	return 0;
}