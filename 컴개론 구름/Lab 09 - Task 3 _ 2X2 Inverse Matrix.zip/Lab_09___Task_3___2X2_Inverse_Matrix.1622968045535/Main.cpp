#include <iostream>
using namespace std;
int main() {
	float Mat[2][2];
	float iv_Mat[2][2];
	float d;
	int i,j;
	// Input into Matrix
	for(int i=0; i < 2;i++){
		for(int j=0; j <2;j++){
			cin >> Mat[i][j];
		}
	}
	d = (Mat[0][0]*Mat[1][1])-(Mat[0][1]*Mat[1][0]); // d= ad - bc
	if(d==0){  // if ad - bc is 0, print not inverse Matrix
		cout<<"The inverse does not exist.";
	}else{
	iv_Mat[0][0] = Mat[1][1]/d;   // inverse Matrix[0][0] = d / ad-bc
	iv_Mat[0][1] = -Mat[0][1]/d;  // inverse Matrix[0][1] = -b / ad-bc
	iv_Mat[1][0] = -Mat[1][0]/d;  // inverse Matrix[0][0] = -c / ad-bc
	iv_Mat[1][1] = Mat[0][0]/d;  // inverse Matrix[0][0] = a / ad-bc
	// print inverse Matrix
	for(int i=0;i<2;i++){
		for(int j=0;j<2;j++){
			cout<< iv_Mat[i][j]<<'\t';
		}
		cout<<'\n';
	}
	}
	return 0;
}