#include <iostream>
using namespace std;
int main() {
	int N,M;  // N = row, M = column
	cin >> N >> M;
	int mat[N][M];  // matrix
	int tran_mat[M][N]; // tranpose matrix
	// input into matrix
	for(int i=0; i<N; i++){
		for(int j=0; j<M; j++){
			cin >> mat[i][j];
		}
	}
	// tranpose the matrix 
	for(int i=0; i<N; i++){
		for(int j=0; j<M; j++){
			tran_mat[j][i] = mat[i][j];
		}
	}
	// print the tranpose matrix
	for(int i=0; i<M; i++){
		for(int j=0; j<N; j++){
			cout<<tran_mat[i][j]<<" ";
		}
		cout << '\n';
	}
	return 0;
}