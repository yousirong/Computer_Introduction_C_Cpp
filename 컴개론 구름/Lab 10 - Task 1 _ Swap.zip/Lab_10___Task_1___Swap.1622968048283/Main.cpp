#include <iostream>
using namespace std;

void swap(int *x, int *y){
	int temp = (*y);
	(*y) = (*x);
	(*x) = temp;
}

int main() {
	int a, b, c;
	cin >> a >> b >> c;
	int swapnum[3] = {a,b,c};
	// cout <<swapnum[0]<<swapnum[1]<<swapnum[2];
	for(int i=0; i<2; i++){
		for(int j=i+1; j <=2; j++){
			if(swapnum[i] > swapnum[j]){
				swap(&swapnum[i], &swapnum[j]);
			}
		}
	}
	a = swapnum[0];
	b = swapnum[1];
	c = swapnum[2];
	cout << a << " " << b << " " << c << endl;
	return 0;
}