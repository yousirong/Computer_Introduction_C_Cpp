#include <iostream>
using namespace std;

int add(int a, int b){return a + b;}
int sub(int a, int b){return a - b;}
int multi(int a, int b){return a * b;}
int divi(int a, int b){return a / b;}

int main() {
	int x, y; //연산할 두 정수
	cin >> x >> y;
	int (*fun[4])(int, int);
	
	fun[0] = add;  // 첫 번째 요소에 덧셈 함수의 메모리 주소 저장   
	fun[1] = sub;  // 두 번째 요소에 뺄셈 함수의 메모리 주소 저장
	fun[2] = multi;  // 세 번째 요소에 곱셈 함수의 메모리 주소 저장
	fun[3] = divi;  // 네 번째 요소에 나눗셈 함수의 메모리 주소 저장
	for(int i = 0; i < 4; i++)
		cout << fun[i](x, y) << endl;
	return 0;
}