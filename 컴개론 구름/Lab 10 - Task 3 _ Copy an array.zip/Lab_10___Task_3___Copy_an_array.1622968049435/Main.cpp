#include <iostream>
using namespace std;
int main() {
	int n;
	cin >> n;
	int a[4];
	for(int i=0; i<4;i++){
		cin >> a[i];
	}
	
	int *pArr;
	pArr = (int*)malloc(sizeof(int)*n);
	
	if(pArr == NULL){
		cout << "malloc error";
	}
	for(int i=0; i<n;i++){
		pArr[i] = a[i];
		cout << pArr[i] << " ";
	}
	

	
	free(pArr);
	return 0;
}