#include <iostream>
using namespace std;
int main() {
	int num;
	int aver = 0;

	cout << "How many subjects will you save? ";
	cin >> num;
	
	if(num == 0){
		return 0;
	}
	
	int *pArr;
	pArr = (int*)malloc(sizeof(int)*num);
	
	if(pArr == NULL){
		cout << "malloc error";
	}
	
	for(int i=0; i<num;i++){
		cout << i+1 <<") score is ";
		cin >> pArr[i];
	}
	
	for(int i = 0; i < num; i++){
		cout << "The score of the (" << i+1 << ") subject is " << pArr[i] << endl;
		aver += pArr[i];
	}
	aver = aver / num;
	
	
	free(pArr);
	cout << "The average for all subjects is " << aver <<endl;
	
	
	
	return 0;
}