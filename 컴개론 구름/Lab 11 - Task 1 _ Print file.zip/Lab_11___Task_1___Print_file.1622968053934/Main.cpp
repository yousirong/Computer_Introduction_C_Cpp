#include <iostream>
#include <fstream>
using namespace std;

int main(){
	ifstream readFile;
	
	char c;
 	readFile.open("data/test.txt");
	
	if(readFile.is_open()){
	while(readFile.get(c)){
		cout << c;
	}
	readFile.close();
	}
	return 0;
}