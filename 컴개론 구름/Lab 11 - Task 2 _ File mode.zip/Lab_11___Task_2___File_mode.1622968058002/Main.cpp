#include <iostream>
#include <fstream>
using namespace std;

int main() {
	fstream myFile;
	myFile.open("data/test.txt",ios::in);
	char c;
	if(!myFile) {
		cout << "File not created!";
	}
	else {
		cout << "File created successfully!\n";
		while(myFile.get(c)){
		cout << c;
	}
	}
	
	myFile.close();
	return 0;
}