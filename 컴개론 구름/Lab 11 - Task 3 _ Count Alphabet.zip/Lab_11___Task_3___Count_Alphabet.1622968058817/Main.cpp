#include <iostream>
#include <fstream>
using namespace std;

int main() {
	char* arr = (char*)calloc(2000, sizeof(char));
	int alpha[26];
	int end = 0;

	ifstream myFile;
	myFile.open("data/music.txt");
	if (!myFile) {
		cout << "Failed to open file!" << endl;
		return 0;
	}
	// myFile 내용 받아오기, eof에 대해서 찾아보고 공부해보세요!
	for (int i = 0; myFile.eof() == 0; i++) {
		myFile >> arr[i];
		end++;
	}
	for (int i = 0; i < 26; i++) {
		alpha[i] = 0;
		for (int j = 0; j < end; j++) {
			if(arr[j] == (i+ 'a') || arr[j] == (i + 'A')){
				alpha[i]++;
			}
			}
		}

	

	for (int i = 0; i < 26; i++) {
		cout << char(i+65) << " : " << alpha[i] << endl;
	}
	myFile.close();
	delete[] arr;

	
	
	return 0;
}