#include <iostream>
#include <math.h>   // pow = > 제곱,   sqrt 제곱근
using namespace std;
struct Location { 
	int x;
	int y;
};
int main() {
	Location first;
	cin >> first.x >> first.y; 
	Location second;
	cin >> second.x >> second.y;
	// cout << first.x << first.y;
	// cout << second.x << second.y;
	double distance;
	distance = sqrt(pow(first.x - second.x,2) + pow(first.y - second.y,2)); 
	// sqrt((x1-x2)^2 + (y1-y2)^2)
	cout <<distance<<endl;
	return 0;
}