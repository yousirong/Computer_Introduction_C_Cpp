#include <iostream>
using namespace std;
struct Date{
	int month;
	int day;
	int year;
};
struct Student{
	int number;
	char name[20];
	double grade;
	struct Date date;
};


int main() {
	Student stu;
	cin >> stu.date.month >> stu.date.day >> stu.date.year;
	cin >> stu.number >> stu.name >> stu.grade;
	cout << "학번 : "<< stu.number<<"\n";
	cout << "이름 : "<< stu.name<<"\n";
	cout << "학점 : "<< stu.grade<<"\n";
	cout << "생년월일 : "<<stu.date.year <<"/"<<stu.date.month << "/"<<stu.date.day<<endl;
	return 0;
}