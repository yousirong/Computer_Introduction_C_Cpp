#include <iostream>
using namespace std;
struct menu{
	char name[30];
	int calories;
};
int main() {
	struct menu p[3];   // 크기가 3인 구조체 배열 생성
	cin >> p[0].name >> p[0].calories;
	cin >> p[1].name >> p[1].calories;
	cin >> p[2].name >> p[2].calories;
	cout << "The total calories in today\'s diet are " << 
		p[0].calories+p[1].calories+p[2].calories<<"kcal"<<endl;
	return 0;
}