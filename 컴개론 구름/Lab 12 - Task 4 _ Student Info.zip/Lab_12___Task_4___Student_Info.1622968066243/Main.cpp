#include <iostream>
using namespace std;
#define STU_NUM  1  // 학생번호
#define REG_NUM  2   // 주민번호
//필요한 부분은 추가해서 작성하세요.

struct student {
	int type;
		union {
			struct{
			char id[20];  // 학번 
			char regnum[20];  // 주민 번호
			char name[20];  // 이름
			};
		};
};


void print(struct student s) {
	switch(s.type) {
		case STU_NUM :
			cout << "학번 : " << s.id<< endl;
			cout << "이름 : " <<s.name;
			break;
		case REG_NUM :
			cout << "주민등록번호 : " << s.regnum << endl;
			cout << "이름 : " << s.name;
			break;
		default:
			cout<< "type error"<< endl;
	}
}

int main() {
	struct student stu;
	
	cin >> stu.type >> stu.id >> stu.regnum >> stu.name;
	print(stu);
	return 0;
}