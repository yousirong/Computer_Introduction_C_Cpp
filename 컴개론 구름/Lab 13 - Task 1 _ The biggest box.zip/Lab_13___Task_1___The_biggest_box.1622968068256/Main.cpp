#include <iostream>
using namespace std;

class Box{
	private:
		double width;
		double length;
		double height;
	public:
		Box();
		Box(double width, double length, double height);
		double getVolume();
		void setLength(double length);
		void setWidth(double width);
		void setHeight(double heigth);
		double getLength();
		double getWidth();
		double getHeight();
};
Box::Box(){
	this->length = 4.0;
	this->width = 4.0;
	this->height = 3.2;
}
Box::Box(double w, double l, double h){
	this->width = w;
	this->length = l;
	this->height = h;
}
void Box::setLength(double length){
	this->length = length;
}
void Box::setWidth(double width){
	this->width = width;
}
void Box::setHeight(double height){
	this->height = height;
}
double Box::getVolume(){
	return length * width * height;
}

int main(){
	
	double w,l,h;
	double ans1, ans2, ans3, max;
	Box Box1(3.4, 5.5, 5.0);
	ans1 = Box1.getVolume();
	Box Box2;
	ans2 = Box2.getVolume();
	cin >> w >> l >> h;
	Box Box3;
	Box3.setLength(l);
	Box3.setWidth(w);
	Box3.setHeight(h);
	
	ans3 = Box3.getVolume();
	max = ans1;
	if(max < ans2){
		if (ans2 > ans3){
			max = ans2;
		}
		else{
			max = ans3;
		}
	}else{
		if(max < ans3)
		{
			max = ans3;
		}
	}
	cout << max <<endl;
}