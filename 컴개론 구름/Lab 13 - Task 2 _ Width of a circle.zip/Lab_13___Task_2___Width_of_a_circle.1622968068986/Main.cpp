#include <iostream>
using namespace std;
#define MAX 100

class Circle{
	private :
		double radius;
	public :
		void setRadius(double radius);
		double getArea();
};

double Circle::getArea(){
	return radius * radius * 3.14;
}

void Circle::setRadius(double radius){
	this->radius = radius;
}

int main(){
	Circle cir[MAX];
	int x ,r;
	cin >> x;
	for(int i = 0; i < x; i++){
		cin >> r;
		cir[i].setRadius(r);
	}
	
	for(int i=0; i<x; i++){
		cout << cir[i].getArea()<<endl;
	}
	
}