#include <iostream>
#include <string>
using namespace std;

class Date {
	private:
		int year;
		int month;
		int day;
	public:
		Date() {
		cout << "Date default construct" << endl;
		}
		Date(int y, int m, int d) { 
			cout << "Date construct with 3 parameters" << endl;
			this->year = y;
			this->month = m;
			this->day = d;
		}
		~Date() {
		cout << "Date distructer" << endl;
		}
		int getYear() {
			return year;
		}
		int getMonth() {
			return month;
		}
		int getDay() {
			return day;
		}
		void setYear(int y) {
			this->year = y;
		}
		void setMonth(int m) {
			this->month = m;
		}
		void setDay(int d) {
			this->day = d;
		}	
		void print() {
			cout << year << " "<< month << " "<< day << " "<< endl;
		}	
};

class Employee {
	private:
		string name;
		Date birthDay;
		Date hireDay;
	public:
		Employee(){
		}
		~Employee(){
		}
		Employee(string name, const Date& birthDay, Date& hireDay)
		{
			cout << "Employee construct with 3 parameters" << endl;
			this->name = name;
			this->birthDay = birthDay;
			this->hireDay = hireDay;
		}
		void print()
		{
			cout << name <<endl;
			birthDay.print();
			hireDay.print();
		}
};

int main()
{
	Date birth(1993, 9, 10);
	Date hire(2018, 3, 1);
	Employee emp("tina", birth, hire);
	emp.print();
	birth.print();
	Employee emp1;

	return 0;
}